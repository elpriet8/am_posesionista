package com.example.am_posesionista

import androidx.lifecycle.ViewModel
import java.util.*

class TablaCosasViewModel: ViewModel() {
    val inventory = mutableListOf<Cosa>()
    val nombres = arrayOf("Teléfono", "Pan", "Playera")
    val adjetivos = arrayOf("Gris", "Suave", "Cómoda")

    init{
        for(i in 0 until 100){
            val cosa = Cosa()
            val randName = nombres.random()
            val randAdj = adjetivos.random()
            val randPrice = Random().nextInt(100)
            cosa.nombreCosa = "$randName $randAdj"
            cosa.valorPesos = randPrice
            inventory += cosa
        }
    }
}