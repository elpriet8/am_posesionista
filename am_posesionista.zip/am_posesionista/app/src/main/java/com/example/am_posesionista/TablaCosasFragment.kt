package com.example.am_posesionista

import android.annotation.SuppressLint
import android.content.Context
import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.lifecycle.ViewModelProvider
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import javax.security.auth.callback.Callback

private const val TAG = "debug"
class TablaCosasFragment : Fragment(){
    private lateinit var cosaRecyclerView: RecyclerView
    private var adaptador: CosaAdapter? = null
    private var callbackInterfaz: InterfazTablaCosas? = null

    interface InterfazTablaCosas{
        fun onCosaSeleccionada(unaCosa: Cosa)
    }

    override fun onAttach(context: Context){
        super.onAttach(context)
        callbackInterfaz = context as InterfazTablaCosas?
    }

    override fun onDetach() {
        super.onDetach()
        callbackInterfaz = null
    }

    private fun actualizaUI(){
        val inventario = tablaDeCosasViewModel.inventory
        adaptador = CosaAdapter(inventario)
        cosaRecyclerView.adapter = adaptador
    }

    private val tablaDeCosasViewModel: TablaCosasViewModel by lazy{
        ViewModelProvider(this).get(TablaCosasViewModel::class.java)

    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Log.d(TAG, "total de cosas ${tablaDeCosasViewModel.inventory.size}")
    }

    companion object{
        fun nuevaInstancia(): TablaCosasFragment{
            return TablaCosasFragment()
        }
    }

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        val view = inflater.inflate(R.layout.lista_cosas_fragment, container,false)
        cosaRecyclerView = view.findViewById(R.id.cosa_recycler_view) as RecyclerView
        // Tipo de layout
        cosaRecyclerView.layoutManager = LinearLayoutManager(context)
        actualizaUI()
        return view
    }

    private inner class CosaHolder(view: View) : RecyclerView.ViewHolder(view), View.OnClickListener{
        // Item View es propiedad que toma lo que recibe CosaHolder como parametro
        private val nombreTextView: TextView = itemView.findViewById(R.id.label_nombre)
        private val precioTextView :TextView = itemView.findViewById(R.id.label_precio)
        private lateinit var cosa: Cosa

        init { itemView.setOnClickListener(this) }

        @SuppressLint("SetTextI18n")
        fun binding(cosa:Cosa){
            this.cosa = cosa
            nombreTextView.text = cosa.nombreCosa
            precioTextView.text = "$" + cosa.valorPesos.toString()
        }

        override fun onClick(v: View?){
            callbackInterfaz?.onCosaSeleccionada(cosa)
            Toast.makeText(context, "hola",Toast.LENGTH_SHORT).show()
        }

    }

    private inner class CosaAdapter(var inventario: List<Cosa>):RecyclerView.Adapter<CosaHolder>(){

        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): CosaHolder {
            // parent se recibe como parametro, tipo viewgroup
            val holder = layoutInflater.inflate(R.layout.cosa_layout, parent, false)

            // Attach to Root,
            return CosaHolder(holder)
        }

        // Size of inventory, by param
        override fun getItemCount(): Int { return inventario.size }

        override fun onBindViewHolder(holder: CosaHolder, position: Int) {
           val cosa = inventario[position]
          /*holder.apply {
               nombreTextView.text = cosa.nombreCosa
               precioTextView.text = "$ ${cosa.valorPesos.toString()}"
            }*/
            holder.binding(cosa)
        }

    }
}