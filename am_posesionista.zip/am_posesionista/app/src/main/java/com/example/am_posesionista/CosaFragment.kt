package com.example.am_posesionista

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.EditText
import android.widget.TextView
import androidx.fragment.app.Fragment

class CosaFragment: Fragment() {
    private lateinit var cosa:Cosa
    private lateinit var nameField: EditText
    private lateinit var priceField: EditText
    private lateinit var serialField: EditText
    private lateinit var dateField: TextView

    override fun onCreate(savedInstanceState: Bundle?){
        super.onCreate(savedInstanceState)
        cosa = Cosa()
    }
    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        val view = inflater.inflate(R.layout.cosa_fragment, container, false)
        nameField = view.findViewById(R.id.campoNombreCosa) as EditText
        priceField = view.findViewById(R.id.campoPrecioCosa) as EditText
        serialField = view.findViewById(R.id.campoSerialCosa) as EditText
        dateField = view.findViewById(R.id.labelFecha) as TextView
        return view
    }
}