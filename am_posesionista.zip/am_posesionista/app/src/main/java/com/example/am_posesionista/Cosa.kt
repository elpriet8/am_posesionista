package com.example.am_posesionista

import android.os.Parcel
import android.os.Parcelable
import java.util.*

class Cosa(): Parcelable {
    var nombreCosa: String = ""
    var valorPesos: Int = 0
    var serialnum: UUID = UUID.randomUUID()
    var fechaCreacion: Date = Date()

    constructor(parcel: Parcel): this(){
        nombreCosa = parcel.readString().toString()
        valorPesos = parcel.readInt()
        serialnum = parcel.readSerializable() as UUID
        fechaCreacion = parcel.readSerializable() as Date
    }

    override fun writeToParcel(dest: Parcel, flags: Int) {
        dest.writeString(nombreCosa)
        dest.writeInt(valorPesos)
        dest.writeSerializable(serialnum)
        dest.writeSerializable(fechaCreacion)
    }

    override fun describeContents(): Int {
        return 0
    }


    companion object CREATOR: Parcelable.Creator<Cosa>{
        override fun createFromParcel(source: Parcel): Cosa {
            return Cosa(source)
        }

        override fun newArray(size: Int): Array<Cosa?> {
            return arrayOfNulls(size)
        }
    }

}